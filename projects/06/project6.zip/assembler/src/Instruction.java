public interface Instruction {
    public String convertInstructionToBinaryCode();
}
